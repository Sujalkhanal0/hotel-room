#include <graphics.h>
#include <conio.h>
#include <windows.h>
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

const int NORMAL_PRICE = 2000;
const int EXPENSIVE_PRICE = 5000;

// Function to get text input in graphics
string getInput(int x, int y, int maxLength) {
    string input = "";
    char ch;
    while (true) {
        ch = getch();
        if (ch == 13) break;  // Enter
        else if (ch == 8) {   // Backspace
            if (!input.empty()) {
                input.pop_back();
                setcolor(BLACK);
                rectangle(x, y, x + 400, y + 40); // erase previous
                floodfill(x + 1, y + 1, BLACK);
                setcolor(WHITE);
                outtextxy(x + 5, y + 5, const_cast<char*>(input.c_str()));
            }
        } else if (input.size() < maxLength) {
            input.push_back(ch);
            setcolor(WHITE);
            outtextxy(x + 5, y + 5, const_cast<char*>(input.c_str()));
        }
    }
    return input;
}

// Create Room Function
void createRoom(int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int formX = screenWidth / 4;
    int boxWidth = 400, boxHeight = 40;
    int startY = 150, spacing = 80;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 4);
    outtextxy(formX, 50, const_cast<char*>("Create Room Form"));

    // Labels
    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    outtextxy(formX, startY, const_cast<char*>("Full Name:"));
    outtextxy(formX, startY + spacing, const_cast<char*>("Phone:"));
    outtextxy(formX, startY + spacing * 2, const_cast<char*>("Address:"));
    string roomLabel = "Room Type (1=Normal,2=Expensive):";
    outtextxy(formX, startY + spacing * 3, const_cast<char*>(roomLabel.c_str()));

    // Input boxes
    int boxX = formX + 300; // Boxes for first 3 fields
    rectangle(boxX, startY, boxX + boxWidth, startY + boxHeight);
    rectangle(boxX, startY + spacing, boxX + boxWidth, startY + spacing + boxHeight);
    rectangle(boxX, startY + spacing * 2, boxX + boxWidth, startY + spacing * 2 + boxHeight);

    // Room Type input aligned after colon
    size_t colonPos = roomLabel.find(':');
    string beforeColon = roomLabel.substr(0, colonPos + 1);
    char temp[beforeColon.size() + 1];
    strcpy(temp, beforeColon.c_str());
    int labelWidth = textwidth(temp);

    int roomBoxX = formX + labelWidth + 10;
    rectangle(roomBoxX, startY + spacing * 3, roomBoxX + 100, startY + spacing * 3 + boxHeight);

    // Get input
    string name = getInput(boxX + 5, startY + 5, 30);
    string phone = getInput(boxX + 5, startY + spacing + 5, 15);
    string address = getInput(boxX + 5, startY + spacing * 2 + 5, 50);
    string roomTypeStr = getInput(roomBoxX + 5, startY + spacing * 3 + 5, 1);

    int roomType = (roomTypeStr == "2") ? 2 : 1;
    int price = (roomType == 2 ? EXPENSIVE_PRICE : NORMAL_PRICE);

    // Save to file using phone as filename
    string filename = phone + ".txt";
    ofstream file(filename, ios::app);
    if (file.is_open()) {
        file << name << "|" << phone << "|" << address << "|"
             << (roomType == 2 ? "Expensive" : "Normal") << "|"
             << price << "\n";
        file.close();
    }

    // Confirmation message
    cleardevice();
    setcolor(LIGHTCYAN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    outtextxy(formX, startY + 50, const_cast<char*>("Room Created Successfully!"));
    outtextxy(formX, startY + 100, const_cast<char*>("Press any key to return to menu."));
    getch();
}

// Show Room List Function
void showRoomList(int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int formX = screenWidth / 10;
    int startY = 50;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 4);
    outtextxy(formX, startY, const_cast<char*>("Booking List"));

    // Ask for phone number
    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    string phoneLabel = "Enter phone number to view booking:";
    outtextxy(formX, startY + 70, const_cast<char*>(phoneLabel.c_str()));

    // Calculate width of label to position input box after colon
    size_t colonPos = phoneLabel.find(':'); 
    string labelBeforeColon = phoneLabel.substr(0, colonPos + 1);
    char temp[labelBeforeColon.size() + 1];
    strcpy(temp, labelBeforeColon.c_str());
    int labelWidth = textwidth(temp);

    int boxX = formX + labelWidth + 10; // 10 px gap after colon
    int boxY = startY + 70;
    int boxWidth = 260, boxHeight = 40;
    rectangle(boxX, boxY, boxX + boxWidth, boxY + boxHeight);

    string phone = getInput(boxX + 5, boxY + 5, 15);

    string filename = phone + ".txt";
    ifstream file(filename);
    if (!file.is_open()) {
        setcolor(LIGHTRED);
        outtextxy(formX, startY + 150, const_cast<char*>("No booking found with this phone number."));
        getch();
        return;
    }

    // Table header
    setcolor(LIGHTCYAN);
    int tableY = startY + 150;
    int colX[] = {formX + 20, formX + 300, formX + 450, formX + 700, formX + 1000}; // columns with spacing
    outtextxy(colX[0], tableY, const_cast<char*>("Full Name"));
    outtextxy(colX[1], tableY, const_cast<char*>("Phone"));
    outtextxy(colX[2], tableY, const_cast<char*>("Address"));
    outtextxy(colX[3], tableY, const_cast<char*>("Room Type"));
    outtextxy(colX[4], tableY, const_cast<char*>("Price"));

    // Read and display data
    string line;
    int row = 1;
    while (getline(file, line)) {
        int yPos = tableY + row * 50;
        size_t pos = 0;
        string token;
        int col = 0;

        while ((pos = line.find('|')) != string::npos && col < 5) {
            token = line.substr(0, pos);
            outtextxy(colX[col], yPos, const_cast<char*>(token.c_str()));
            line.erase(0, pos + 1);
            col++;
        }
        if (!line.empty() && col < 5) {
            outtextxy(colX[col], yPos, const_cast<char*>(line.c_str()));
        }
        row++;
    }

    file.close();
    outtextxy(formX, tableY + (row + 1) * 50, const_cast<char*>("Press any key to return to menu."));
    getch();
}

// Delete Booking Function
void deleteBooking(int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int formX = screenWidth / 10;
    int startY = 100;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 4);
    outtextxy(formX, startY, const_cast<char*>("Delete Booking"));

    // Ask for phone number
    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    string phoneLabel = "Enter phone number to delete booking:";
    outtextxy(formX, startY + 70, const_cast<char*>(phoneLabel.c_str()));

    size_t colonPos = phoneLabel.find(':'); 
    string labelBeforeColon = phoneLabel.substr(0, colonPos + 1);
    char temp[labelBeforeColon.size() + 1];
    strcpy(temp, labelBeforeColon.c_str());
    int labelWidth = textwidth(temp);

    int boxX = formX + labelWidth + 10;
    int boxY = startY + 70;
    int boxWidth = 260, boxHeight = 40;
    rectangle(boxX, boxY, boxX + boxWidth, boxY + boxHeight);

    string phone = getInput(boxX + 5, boxY + 5, 15);
    string filename = phone + ".txt";

    if (remove(filename.c_str()) != 0) {
        setcolor(LIGHTRED);
        outtextxy(formX, startY + 150, const_cast<char*>("No booking found to delete."));
    } else {
        setcolor(LIGHTCYAN);
        outtextxy(formX, startY + 150, const_cast<char*>("Booking deleted successfully."));
    }

    outtextxy(formX, startY + 200, const_cast<char*>("Press any key to return to menu."));
    getch();
}

// Your existing menu code
void showMenu(int selected, int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    // Title
    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 5);
    outtextxy(screenWidth / 2 - 250, 50, const_cast<char*>("HOTEL MANAGEMENT"));

    // Menu options
    const char* options[] = {"Room Booking", "Booking List", "Delete Booking", "Exit"};
    int numOptions = 4;
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);

    int startY = screenHeight / 2 - (numOptions * 50 + (numOptions - 1) * 20) / 2;
    int optionX = screenWidth / 2 - 500;

    for (int i = 0; i < numOptions; i++) {
        if (i == selected) setcolor(YELLOW);
        else setcolor(WHITE);
        outtextxy(optionX, startY + i * 70, const_cast<char*>(options[i]));
    }

    // Prices on right side
    setcolor(CYAN);
    outtextxy(screenWidth - 500, startY, const_cast<char*>("Normal: 2000"));
    outtextxy(screenWidth - 500, startY + 70, const_cast<char*>("Expensive: 5000"));
}

// Main function
int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, const_cast<char*>(""));

    // Fullscreen
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    initwindow(screenWidth, screenHeight, "Hotel Management", -3, -3);

    int selected = 0;
    int key;

    while (true) {
        showMenu(selected, screenWidth, screenHeight);

        key = getch();
        if (key == 0 || key == 224) { // Arrow keys
            key = getch();
            if (key == 72) selected = (selected - 1 + 4) % 4; // Up
            if (key == 80) selected = (selected + 1) % 4;     // Down
        } else if (key == 13) { // Enter
            cleardevice();
            setcolor(GREEN);
            settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
            if (selected == 0) {
                createRoom(screenWidth, screenHeight); // Call Create Room
            }
            else if (selected == 1) {
                showRoomList(screenWidth, screenHeight); // Call Room List
            }
            else if (selected == 2) {
                deleteBooking(screenWidth, screenHeight); // Call Delete Booking
            }
            else if (selected == 3) {
                outtextxy(screenWidth / 2 - 100, screenHeight / 2, const_cast<char*>("Exiting..."));
                getch();
                break;
            }
            getch();
        }
    }

    closegraph();
    return 0;
}
