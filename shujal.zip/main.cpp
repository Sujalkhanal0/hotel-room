#include <graphics.h>
#include <conio.h>
#include <windows.h>
#include <fstream>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

const int NORMAL_PRICE = 2000;
const int EXPENSIVE_PRICE = 5000;
const int MAX_ROOMS = 20;

string getInput(int x, int y, int maxLength, bool hide = false) {
    string input = "";
    char ch;
    while (true) {
        ch = getch();
        if (ch == 27) return "ESC";
        if (ch == 13) break;
        else if (ch == 8) {
            if (!input.empty()) {
                input.pop_back();
                setcolor(BLACK);
                rectangle(x, y, x + 400, y + 40);
                floodfill(x + 1, y + 1, BLACK);
                setcolor(WHITE);
                string display = hide ? string(input.size(), '*') : input;
                outtextxy(x + 5, y + 5, const_cast<char*>(display.c_str()));
            }
        } else if (input.size() < maxLength && ch >= 32 && ch <= 126) {
            input.push_back(ch);
            setcolor(WHITE);
            string display = hide ? string(input.size(), '*') : input;
            outtextxy(x + 5, y + 5, const_cast<char*>(display.c_str()));
        }
    }
    return input;
}

int getNextRoomKey() {
    ifstream keyFile("roomkey.txt");
    int key = 1;
    if (keyFile.is_open()) {
        keyFile >> key;
        key++;
        keyFile.close();
    }
    ofstream outKey("roomkey.txt");
    outKey << key;
    outKey.close();
    return key;
}

int getTotalBookings() {
    WIN32_FIND_DATA findFileData;
    HANDLE hFind = FindFirstFile("*.txt", &findFileData);
    int count = 0;
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            string fname = findFileData.cFileName;
            if (fname != "roomkey.txt") count++;
        } while (FindNextFile(hFind, &findFileData));
        FindClose(hFind);
    }
    return count;
}

void createRoom(int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int formX = screenWidth / 4;
    int boxWidth = 400, boxHeight = 40;
    int startY = 150, spacing = 80;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 4);
    outtextxy(formX, 50, const_cast<char*>("Create Room Form"));

    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    outtextxy(formX, startY, const_cast<char*>("Full Name:"));
    outtextxy(formX, startY + spacing, const_cast<char*>("Phone:"));
    outtextxy(formX, startY + spacing * 2, const_cast<char*>("Address:"));
    string roomLabel = "Room Services (1=Normal,2=Expensive):";
    outtextxy(formX, startY + spacing * 3, const_cast<char*>(roomLabel.c_str()));
    outtextxy(formX, startY + spacing * 4, const_cast<char*>("No. of Days:"));

    int boxX = formX + 300;
    rectangle(boxX, startY, boxX + boxWidth, startY + boxHeight);
    rectangle(boxX, startY + spacing, boxX + boxWidth, startY + spacing + boxHeight);
    rectangle(boxX, startY + spacing * 2, boxX + boxWidth, startY + spacing * 2 + boxHeight);

    size_t colonPos = roomLabel.find(':');
    string beforeColon = roomLabel.substr(0, colonPos + 1);
    char temp[beforeColon.size() + 1];
    strcpy(temp, beforeColon.c_str());
    int labelWidth = textwidth(temp);
    int roomBoxX = formX + labelWidth + 10;
    rectangle(roomBoxX, startY + spacing * 3, roomBoxX + 100, startY + spacing * 3 + boxHeight);
    rectangle(boxX, startY + spacing * 4, boxX + 100, startY + spacing * 4 + boxHeight);

    string name = getInput(boxX + 5, startY + 5, 30); if (name == "ESC") return;
    string phone = getInput(boxX + 5, startY + spacing + 5, 15); if (phone == "ESC") return;
    string address = getInput(boxX + 5, startY + spacing * 2 + 5, 50); if (address == "ESC") return;
    string roomTypeStr = getInput(roomBoxX + 5, startY + spacing * 3 + 5, 1); if (roomTypeStr == "ESC") return;
    string daysStr = getInput(boxX + 5, startY + spacing * 4 + 5, 3); if (daysStr == "ESC") return;

    int roomType = (roomTypeStr == "2") ? 2 : 1;
    int days = stoi(daysStr);
    int pricePerDay = (roomType == 2 ? EXPENSIVE_PRICE : NORMAL_PRICE);
    int totalPrice = pricePerDay * days;
    int roomKey = getNextRoomKey();

    string filename = to_string(roomKey) + ".txt";
    ofstream file(filename, ios::app);
    if (file.is_open()) {
        file << roomKey << "|" << name << "|" << phone << "|" << address << "|"
             << (roomType == 2 ? "Expensive" : "Normal") << "|" << days << "|" << totalPrice << "\n";
        file.close();
    }

    cleardevice();
    setcolor(LIGHTCYAN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    outtextxy(formX, startY + 50, const_cast<char*>("Room Created Successfully!"));
    string keyMsg = "Room Key: " + to_string(roomKey);
    outtextxy(formX, startY + 100, const_cast<char*>(keyMsg.c_str()));
    outtextxy(formX, startY + 150, const_cast<char*>("Press any key to return to menu."));
    getch();
}

void showRoomList(int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int formX = screenWidth / 10;
    int startY = 50;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 4);
    outtextxy(formX, startY, const_cast<char*>("Booking List"));

    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    string keyLabel = "Enter Room Key to view booking:";
    outtextxy(formX, startY + 70, const_cast<char*>(keyLabel.c_str()));

    size_t colonPos = keyLabel.find(':');
    string labelBeforeColon = keyLabel.substr(0, colonPos + 1);
    char temp[labelBeforeColon.size() + 1];
    strcpy(temp, labelBeforeColon.c_str());
    int labelWidth = textwidth(temp);

    int boxX = formX + labelWidth + 10;
    int boxY = startY + 70;
    int boxWidth = 260, boxHeight = 40;
    rectangle(boxX, boxY, boxX + boxWidth, boxY + boxHeight);

    string roomKey = getInput(boxX + 5, boxY + 5, 15);
    if (roomKey == "ESC") return;

    string filename = roomKey + ".txt";
    ifstream file(filename);
    if (!file.is_open()) {
        setcolor(LIGHTRED);
        outtextxy(formX, startY + 150, const_cast<char*>("No booking found with this Room Key."));
        getch();
        return;
    }

    setcolor(LIGHTCYAN);
    int lineY = startY + 150;
    string line;
    while (getline(file, line)) {
        size_t pos = 0;
        vector<string> fields;
        while ((pos = line.find('|')) != string::npos) {
            fields.push_back(line.substr(0, pos));
            line.erase(0, pos + 1);
        }
        if (!line.empty()) fields.push_back(line);

        if (fields.size() >= 7) {
            outtextxy(formX, lineY, const_cast<char*>(("Room Key: " + fields[0]).c_str())); lineY += 40;
            outtextxy(formX, lineY, const_cast<char*>(("Name: " + fields[1]).c_str())); lineY += 40;
            outtextxy(formX, lineY, const_cast<char*>(("Phone: " + fields[2]).c_str())); lineY += 40;
            outtextxy(formX, lineY, const_cast<char*>(("Address: " + fields[3]).c_str())); lineY += 40;
            outtextxy(formX, lineY, const_cast<char*>(("Service: " + fields[4]).c_str())); lineY += 40;
            outtextxy(formX, lineY, const_cast<char*>(("Days: " + fields[5]).c_str())); lineY += 40;
            outtextxy(formX, lineY, const_cast<char*>(("Price: " + fields[6]).c_str())); lineY += 60;
        }
    }

    file.close();
    outtextxy(formX, lineY + 20, const_cast<char*>("Press any key to return to menu."));
    getch();
}

void deleteBooking(int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int formX = screenWidth / 10;
    int startY = 100;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 4);
    outtextxy(formX, startY, const_cast<char*>("Delete Booking"));

    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    string keyLabel = "Enter Room Key to delete booking:";
    outtextxy(formX, startY + 70, const_cast<char*>(keyLabel.c_str()));

    size_t colonPos = keyLabel.find(':');
    string labelBeforeColon = keyLabel.substr(0, colonPos + 1);
    char temp[labelBeforeColon.size() + 1];
    strcpy(temp, labelBeforeColon.c_str());
    int labelWidth = textwidth(temp);

    int boxX = formX + labelWidth + 10;
    int boxY = startY + 70;
    int boxWidth = 260, boxHeight = 40;
    rectangle(boxX, boxY, boxX + boxWidth, boxY + boxHeight);

    string roomKey = getInput(boxX + 5, boxY + 5, 15);
    if (roomKey == "ESC") return;

    string filename = roomKey + ".txt";
    if (remove(filename.c_str()) != 0) {
        setcolor(LIGHTRED);
        outtextxy(formX, startY + 150, const_cast<char*>("No booking found to delete."));
    } else {
        setcolor(LIGHTCYAN);
        outtextxy(formX, startY + 150, const_cast<char*>("Booking deleted successfully."));
    }

    outtextxy(formX, startY + 200, const_cast<char*>("Press any key to return to menu."));
    getch();
}

bool loginScreen(int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int formX = screenWidth / 4;
    int startY = 150;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 5);
    outtextxy(formX+200, startY - 100, const_cast<char*>("Login"));

    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    outtextxy(formX, startY, const_cast<char*>("Username:"));
    outtextxy(formX, startY + 100, const_cast<char*>("Password:"));

    int boxWidth = 300, boxHeight = 40;
    int userBoxX = formX + 250, passBoxX = userBoxX;
    rectangle(userBoxX, startY, userBoxX + boxWidth, startY + boxHeight);
    rectangle(passBoxX, startY + 100, passBoxX + boxWidth, startY + 100 + boxHeight);

    string username = getInput(userBoxX + 5, startY + 5, 20);
    string password = getInput(passBoxX + 5, startY + 100 + 5, 20, true);

    return (username == "sujal" && password == "admin");
}

void showMenu(int selected, int screenWidth, int screenHeight) {
    cleardevice();
    setbkcolor(BLACK);
    cleardevice();

    int totalBookings = getTotalBookings();
    int availableRooms = MAX_ROOMS - totalBookings;

    setcolor(LIGHTGREEN);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 5);
    outtextxy(screenWidth / 2 - 300, 50, const_cast<char*>("Room MANAGEMENT"));

    settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    setcolor(CYAN);
    string roomsInfo = "Total Rooms: " + to_string(MAX_ROOMS) + " | Available: " + to_string(availableRooms);
    outtextxy(screenWidth / 2 - 350, 120, const_cast<char*>(roomsInfo.c_str()));

    const char* options[] = {"Room Booking", "Booking List", "Delete Booking", "Exit"};
    int numOptions = 4;
    int startY = screenHeight / 2 - (numOptions * 50 + (numOptions - 1) * 20) / 2;
    int optionX = screenWidth / 2 - 500;

    for (int i = 0; i < numOptions; i++) {
        if (i == selected) setcolor(YELLOW);
        else setcolor(WHITE);
        outtextxy(optionX, startY + i * 70, const_cast<char*>(options[i]));
    }

    setcolor(CYAN);
    outtextxy(screenWidth -500, startY, const_cast<char*>("Services:-"));
    outtextxy(screenWidth - 500, startY+70, const_cast<char*>("Normal: 2000"));
    outtextxy(screenWidth - 500, startY + 140, const_cast<char*>("Expensive: 5000"));
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, const_cast<char*>(""));
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    initwindow(screenWidth, screenHeight, "Room Management", -3, -3);

    if (!loginScreen(screenWidth, screenHeight)) {
        cleardevice();
        setcolor(RED);
        outtextxy(screenWidth / 2 - 100, screenHeight / 2, const_cast<char*>("Login Failed!"));
        getch();
        closegraph();
        return 0;
    }

    int selected = 0;
    int key;

    while (true) {
        showMenu(selected, screenWidth, screenHeight);
        key = getch();
        if (key == 0 || key == 224) {
            key = getch();
            if (key == 72) selected = (selected - 1 + 4) % 4;
            if (key == 80) selected = (selected + 1) % 4;
        } else if (key == 13) {
            cleardevice();
            if (selected == 0) createRoom(screenWidth, screenHeight);
            else if (selected == 1) showRoomList(screenWidth, screenHeight);
            else if (selected == 2) deleteBooking(screenWidth, screenHeight);
            else if (selected == 3) break;
        }
    }

    closegraph();
    return 0;
}
